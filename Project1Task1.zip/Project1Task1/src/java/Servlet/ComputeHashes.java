/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import javax.servlet.RequestDispatcher;
import sun.misc.BASE64Encoder;

/**
 *
 * @author Ge Jin, andrew id:gjin
 */
public class ComputeHashes extends HttpServlet {

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String input= request.getParameter("inputString");//get the input string value
        if(input==null){// go to the index.jsp first
            RequestDispatcher view = request.getRequestDispatcher("index.jsp");
            view.forward(request, response);
        }
        else {
            String coding="";//get the way to encode
        byte[] messages= input.getBytes();
        String textHex="";
        String textBase="";
        try{
              if(request.getParameter("radios").equals("md5")){//judge if it is MD5 or SHA-1
                  coding= "MD5";
                  request.setAttribute("way", "you use MD5");
                  MessageDigest md= MessageDigest.getInstance("MD5");
                  byte[] newArr= md.digest(messages);//get the MD5 of hash value
                  BASE64Encoder be= new BASE64Encoder();
                  textBase= be.encode(newArr);//compute base64 encoding
                  for(int i=0;i<newArr.length;i++){//compute hexdecimal encoding
                    textHex+= Integer.toString((newArr[i] & 0xff)+0x100, 16).substring(1);
            }
            } else {
                  coding= "SHA-1";
                  request.setAttribute("way", "you use SHA-1");
                  MessageDigest md= MessageDigest.getInstance("SHA1");
                  byte[] newArr= md.digest(messages);
                  BASE64Encoder be= new BASE64Encoder();
                  textBase= be.encode(newArr);
                  for(int i=0;i<newArr.length;i++){
                  textHex+= Integer.toString((newArr[i] & 0xff)+0x100, 16).substring(1);
            }
            }
              //set the attribute of the hex and base, send them to jsp
              request.setAttribute("word", input);
              request.setAttribute("hex", "hex value: "+textHex);
              request.setAttribute("base", "base value: "+textBase);
              //after search, go the the jsp page
              RequestDispatcher view = request.getRequestDispatcher("index.jsp");
              view.forward(request, response);
        } catch(NoSuchAlgorithmException e){               
        }
        }
                
        
    
    }
}
