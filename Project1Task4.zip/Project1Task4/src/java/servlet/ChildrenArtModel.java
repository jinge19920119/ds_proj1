/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author jinge
 */
public class ChildrenArtModel {
    private String pictureTag;// The search string of the desired picture
    private String pictureURL;// The URL of the picture image
    private int pictureWidth;// the original width of the picture
    private int pictureHeight;//the original height of the picture
    
    /**Search on the website to get the url
     * Arguments.
     *
     * @param searchTag The tag of the photo to be searched for.
     */
    public boolean doSearch(String searchTag){
        pictureTag = searchTag;
        String response= "";
        boolean found;
        // Create a URL for the desired page
        String searchURL= "http://digital.library.illinoisstate.edu/cdm/search/collection/icca/searchterm/"+pictureTag+"*/field/subjec/mode/all/conn/and/order/title";
        response= fetch(searchURL);
        /*
         * Find the picture URL to scrape
         *
         * Screen scraping is an art that requires looking at the HTML
         * that is returned creatively and figuring out how to cut out
         * the data that is important to you.
         * 
         * First find the src target that starts with the src="utils/getthumbnail
         * and cut the exact url, and add them to the arraylist
         */
        ArrayList<String> list= new ArrayList<String>();
        int left=0;
        int right=0;
        do{
            if(right==0)//the first time to scrap
                left= response.indexOf("src=\"/utils/getthumbnail");
            else
                left= response.indexOf("src=\"/utils/getthumbnail", right);
            if((left == -1) && (right==0)){//if not found, return false
                found = false;
                return found;
            }
            left+= 5;//delete the src=/ from the string
            right= response.indexOf(" ", left);
            String url= response.substring(left, right);
            if(!list.contains(url)){
                list.add(url);//add it to the arraylist
                
            } else {
                break;//if the arraylist has already contained,then break
            }
            
        } while(list.size()<20);//as one can hold 20 pictures at most
        Random r= new Random();       
        int x= r.nextInt(list.size());//get a random int less than 20
        String url= list.get(x);//get one random url
        int cutLeft= url.indexOf("id");
        cutLeft+=3;
        int cutRight= url.indexOf("\"",cutLeft);//get the id from the url to do the search
        String id= url.substring(cutLeft, cutRight);// Now snip out the part from positions cutLeft to cutRight
        //get the url to do the second search
        searchURL= "http://digital.library.illinoisstate.edu/cdm/singleitem/collection/icca/id/"+id;
        response= fetch(searchURL);//fetch the contents of the page
        cutLeft= response.indexOf("cdm_item_width");//get the original width
        cutLeft+= 23;
        cutRight= response.indexOf("\"",cutLeft);
        pictureWidth= Integer.parseInt(response.substring(cutLeft, cutRight));
        cutLeft= response.indexOf("cdm_item_height");//get the original height
        cutLeft+= 24;
        cutRight= response.indexOf("\"",cutLeft);
        pictureHeight= Integer.parseInt(response.substring(cutLeft, cutRight));
        pictureURL= "http://digital.library.illinoisstate.edu/utils/ajaxhelper/?CISOROOT=icca&CISOPTR="
                +id+"&action=2&";//get the former part of the picture url with picture id
        return true;
//        
    }
    /*
     * Return a URL of an image of appropriate size
     * 
     * Arguments
     * @param picsize The string "mobile" or "desktop" indicating the size of
     * photo requested.
     * @return The URL an image of appropriate size.
     */
    public String pictureSize(String picSize){
        int scale=0;
        /*
        From the picsize string to distinguish from mobile or desktop. Then calculate the 
        exact scale value and width value
        Then add these values to the picture url
         */
        if(picSize.equals("mobile")){
            if(pictureWidth<300){
                scale= 100;
            }else {
                scale= 30000/pictureWidth;
            }
            pictureURL= pictureURL+"DMSCALE="+((Integer)scale).toString() 
                +"&DMWIDTH=300&DMHEIGHT="+((Integer)pictureHeight).toString();
        }else {
            if(pictureWidth<800){
                scale= 100;
            }else {
                scale= 80000/pictureWidth;
            }
            pictureURL= pictureURL+"DMSCALE="+((Integer)scale).toString() 
                +"&DMWIDTH=800&DMHEIGHT="+((Integer)pictureHeight).toString();
        }        
        return pictureURL;
    }
    /*
     * Return the picture tag.  I.e. the search string.
     * 
     * @return The tag that was used to search for the current picture.
     */
    public String getPictureTag(){
        return pictureTag;
    }
    /*
     * Make an HTTP request to a given URL
     * 
     * @param urlString The URL of the request
     * @return A string of the response from the HTTP GET.  This is identical
     * to what would be returned from using curl on the command line.
     */
    private String fetch(String searchURL){
        //get url of the picture
        String response= "";
        try {
            URL url = new URL(searchURL);  
            /*
             * Create an HttpURLConnection.  This is useful for setting headers
             * and for getting the path of the resource that is returned (which 
             * may be different than the URL above if redirected).
             * HttpsURLConnection (with an "s") can be used if required by the site.
             */
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            // Read all the text returned by the server
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
            String str="";
            // Read each line of "in" until done, adding each to "response"
            while ((str = in.readLine()) != null) {
                // str is one line of text readLine() strips newline characters
                response += str;
            }
            in.close();
        } catch (IOException e) {
            
        }
        return response;
        
    }
}
