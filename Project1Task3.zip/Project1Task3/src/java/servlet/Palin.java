/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Ge Jin , andrew id: gjin
 */
public class Palin extends HttpServlet {

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String ua= request.getHeader("User-Agent");
        // determine what type of device our user is
        boolean mobile;
        // prepare the appropriate DOCTYPE for the view pages
        if(ua!=null &&((ua.indexOf("Android")!= -1) || (ua.indexOf("iPhone")!=-1))){
            mobile= true;
            /*
             * This is the latest XHTML Mobile doctype. To see the difference it
             * makes, comment it out so that a default desktop doctype is used
             * and view on an Android or iPhone.
             */
            request.setAttribute("doctype", "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.2//EN\" \"http://www.openmobilealliance.org/tech/DTD/xhtml-mobile12.dtd\">");
        } else {
            mobile = false;
            request.setAttribute("doctype", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">");
        
        }
        String input= request.getParameter("input");//get the parameter value from the input  
        //set the input attribute of the original input
        request.setAttribute("in", "you typed: "+ request.getParameter("input"));
        String nextView= null;
        if(input==null){
            nextView= "index.jsp";//go to the index.jsp first
            RequestDispatcher view = request.getRequestDispatcher(nextView);
            view.forward(request, response);
        }else {
            boolean flag= true;//flag if the string is a palindrome
        String output= "";
        input= input.toLowerCase().replaceAll("[^a-zA-Z0-9]+", "");//convert to lower case 
        // , and keep the string only characters and numbers
        if(input.length()!=0){
           for(int i=0;i<input.length()/2+1;i++){//compare two characters one by one
            if(input.charAt(i)!= input.charAt(input.length()-1-i)){
                flag= false;//if they are not the same, flag equals to false
                break;
            }               
           } 
        }
        //decide which to output according to flag
        if(flag)
            output="this is a palindrome!";
        else 
            output="this is not a palindrome!";        
        request.setAttribute("out", output);
        nextView= "index.jsp";//go to the index.jsp
            RequestDispatcher view = request.getRequestDispatcher(nextView);
            view.forward(request, response);
        }
        
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
