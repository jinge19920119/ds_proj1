/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.math.BigInteger;
import javax.servlet.RequestDispatcher;
/**
 *
 * @author Ge Jin, andrew id: gjin
 */
public class BigCalc extends HttpServlet {

    
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        boolean flag= false;
        String inputx= request.getParameter("inputx");//get parameter value from the request
        String inputy= request.getParameter("inputy");
        String operation= request.getParameter("operation");//get the operation parameter from the request
        String result="";
        BigInteger intx = null;//initialize the BigInteger object
        BigInteger intY = null;
        if(inputx==null){//first go to the index.jsp
            RequestDispatcher view = request.getRequestDispatcher("index.jsp");
            view.forward(request, response);
        } else{
            if(inputx!=null && inputy!=null && operation!=null){//validify all the input
            if(inputx.matches("[0-9]+") && inputy.matches("[0-9]+")){
                flag= true;//if all the characters in the string are numbers
                intx=new BigInteger(inputx);//initialize two bigInteger number
                intY=new BigInteger(inputy);
            }
        }
        if(flag){
            switch(operation) {//operate differently according to the string
                case "add"://add two number
                    result= intx.add(intY).toString();
                    break;
                case "mul"://multiple 
                    result= intx.multiply(intY).toString();
                    break;
                case "prime"://if they are relatively prime
                    if(intx.gcd(intY).intValue()==1){
                        result=intx.toString()+" and "+intY.toString()+ ",they are relatively prime!";
                    }else {
                        result=intx.toString()+" and "+intY.toString()+ ",they are not relatively prime!";
                    }
                    break;
                case "mod"://modulo result
                    result= intx.mod(intY).toString();
                    break;
                case "modInv"://modulo inverse result
                    result= intx.modInverse(intY).toString();
                    break;
                case "pow"://exponent calculation
                    result= intx.pow(intY.intValue()).toString();
                    break;
                default:
                    break;
            } 
        }else {//if validation fails, echo the error message
            result= "error! invalid input!";
        }
        //set result attribute
        request.setAttribute("x", "x: "+inputx);
        request.setAttribute("y", "y: "+inputy);
        request.setAttribute("operation", "operation: "+operation);
        request.setAttribute("result", "result : "+result);
            RequestDispatcher view = request.getRequestDispatcher("index.jsp");
            view.forward(request, response);
            //go to that jsp page
        }
        
    }   
    
}
